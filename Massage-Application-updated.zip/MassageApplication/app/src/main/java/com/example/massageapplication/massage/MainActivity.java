package com.example.massageapplication.massage;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.role.RoleManager;
import android.content.BroadcastReceiver;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Telephony;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.view.GravityCompat;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.example.massageapplication.R;
import com.example.massageapplication.SmsListener;
import com.example.massageapplication.contact.ContactsActivity;
import com.example.massageapplication.databinding.ActivityMainBinding;
import com.example.massageapplication.drawerActivity.Archive;
import com.example.massageapplication.drawerActivity.BlockMessage;
import com.example.massageapplication.language.LanguageSelectionActivity;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {
    private static final int PERMISSIONS_REQUEST_CODE = 100;
    private final ArrayList<SmsModel> smsList = new ArrayList<>();
    private final Map<String, String> contactCache = new HashMap<>();
    private ActivityMainBinding b;
    private SmsAdapter smsAdapter;
    private ActivityResultLauncher<Intent> sendSmsLauncher;
    private ActivityResultLauncher<Intent> intentActivityResultLauncher;
    private SmsListener smsListener;

    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        b = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(b.getRoot());
        smsListener = new SmsListener();
        IntentFilter intentFilter = new IntentFilter("android.provider.Telephony.SMS_RECEIVED");
        registerReceiver(smsListener, intentFilter);  // Register the receiver here
        Log.d("HGP", "SmsListener registered.");

        navDrawerClickS();
        b.messagesRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        smsAdapter = new SmsAdapter(smsList);
        b.messagesRecyclerView.setAdapter(smsAdapter);

        // Check if it's the first time opening the app
        SharedPreferences preferences = getSharedPreferences("AppPreferences", MODE_PRIVATE);
        boolean isFirstTime = preferences.getBoolean("isFirstTime", true);
        prepareIntentLauncher();
        if (isFirstTime) {
            // Show dialog on first-time launch
            requestDefaultSmsRole();
        }

        if (!isDefaultSmsApp()) {
            requestDefaultSmsApp();
        } else {
            // Load messages if the app is already the default SMS app
            loadMessages();
        }

        smsAdapter.setOnItemClickListener(position -> {
            SmsModel selectedSms = smsList.get(position);
            Intent intent = new Intent(MainActivity.this, MessageActivity.class);
            intent.putExtra("address", selectedSms.getSender());
            intent.putExtra("date", selectedSms.getSender());
            sendSmsLauncher.launch(intent);
        });

        b.cvDrawer.setOnClickListener(v -> {
            if (!b.drawerLayout.isDrawerOpen(GravityCompat.START)) {
                b.drawerLayout.openDrawer(GravityCompat.START);
            } else {
                b.drawerLayout.closeDrawer(GravityCompat.START);
            }
        });

        b.fab.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, ContactsActivity.class);
            overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
            sendSmsLauncher.launch(intent);
        });

        sendSmsLauncher = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
            if (result.getResultCode() == RESULT_OK) {
                Intent data = result.getData();
                if (data != null) {
                    loadMessages();
                }
            }
        });

        // Check permissions and load messages immediately
        if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.READ_SMS) != PackageManager.PERMISSION_GRANTED ||
                ContextCompat.checkSelfPermission(this, android.Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions();
        } else {
            loadMessages(); // Load messages immediately if permissions are granted
        }
    }

    private void requestPermissions() {
        ActivityCompat.requestPermissions(this, new String[]{android.Manifest.permission.READ_SMS, android.Manifest.permission.READ_CONTACTS}, PERMISSIONS_REQUEST_CODE);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == PERMISSIONS_REQUEST_CODE) {
            if (grantResults.length > 0) {
                boolean smsPermissionGranted = grantResults[0] == PackageManager.PERMISSION_GRANTED;
                boolean contactsPermissionGranted = grantResults[1] == PackageManager.PERMISSION_GRANTED;

                if (smsPermissionGranted && contactsPermissionGranted) {
                    loadMessages(); // Load messages immediately after permissions are granted
                } else {
                    Toast.makeText(this, "Permissions are required to access messages and contacts.", Toast.LENGTH_LONG).show();
                }
            }
        }
    }

    private void loadMessages() {
        new Handler(Looper.getMainLooper()).post(() -> {
                    b.messagesRecyclerView.setVisibility(View.GONE);
                    b.idPBLoading.setVisibility(View.VISIBLE);
                }
        );
        new Thread(() -> {
            smsList.clear();
            Map<String, SmsModel> uniqueMessages = new HashMap<>();
            ContentResolver cr = getContentResolver();

            Cursor cursor = cr.query(Uri.parse("content://sms/"), null, null, null, "date DESC");
            if (cursor != null) {
                while (cursor.moveToNext()) {
                    String body = cursor.getString(cursor.getColumnIndexOrThrow("body"));
                    String address = cursor.getString(cursor.getColumnIndexOrThrow("address"));
                    long dateMillis = cursor.getLong(cursor.getColumnIndexOrThrow("date"));
                    Date date = new Date(dateMillis);

                    // Extract only date and time
                    String dateStr = android.text.format.DateFormat.format("yyyy-MM-dd", date).toString();
                    String timeStr = android.text.format.DateFormat.format("HH:mm", date).toString();

                    String name = getContactName(address);

                    if (!uniqueMessages.containsKey(address)) {
                        uniqueMessages.put(address, new SmsModel(name, body, dateStr, timeStr, dateMillis, "received"));
                    }
                }
                cursor.close();
            }

            smsList.addAll(uniqueMessages.values());
            Collections.sort(smsList, (m1, m2) -> Long.compare(m2.getDateMillis(), m1.getDateMillis()));

            new Handler(Looper.getMainLooper()).post(() -> {
                b.messagesRecyclerView.setVisibility(View.VISIBLE);
                b.idPBLoading.setVisibility(View.GONE); // Hide ProgressBar
                smsAdapter.notifyDataSetChanged();
            });
        }).start();
    }

    private String getContactName(String phoneNumber) {
        if (contactCache.containsKey(phoneNumber)) {
            return contactCache.get(phoneNumber);
        }

        ContentResolver contentResolver = getContentResolver();
        Uri uri = Uri.withAppendedPath(android.provider.ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(phoneNumber));
        Cursor cursor = contentResolver.query(uri, new String[]{android.provider.ContactsContract.PhoneLookup.DISPLAY_NAME}, null, null, null);
        String contactName = phoneNumber;

        if (cursor != null) {
            if (cursor.moveToFirst()) {
                contactName = cursor.getString(cursor.getColumnIndexOrThrow(android.provider.ContactsContract.PhoneLookup.DISPLAY_NAME));
            }
            cursor.close();
        }

        contactCache.put(phoneNumber, contactName);
        return contactName;
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (isDefaultSmsApp()) {
//            loadMessages();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();

    }

    public void navDrawerClickS() {
        b.navDrawer.layoutLanguage.setOnClickListener(v -> {
            startActivity(new Intent(MainActivity.this, LanguageSelectionActivity.class));
            overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
        });
        b.navDrawer.layoutArchive.setOnClickListener(v -> {
            startActivity(new Intent(MainActivity.this, Archive.class));
            overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
        });
        b.navDrawer.layoutBlockMsg.setOnClickListener(v -> {
            startActivity(new Intent(MainActivity.this, BlockMessage.class));
            overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
        });
    }

    private void requestDefaultSmsApp() {
        Intent intent = new Intent(Telephony.Sms.Intents.ACTION_CHANGE_DEFAULT);
        intent.putExtra(Telephony.Sms.Intents.EXTRA_PACKAGE_NAME, getPackageName());
        startActivity(intent);
    }

    private boolean isDefaultSmsApp() {
        return Telephony.Sms.getDefaultSmsPackage(this).equals(getPackageName());
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // Unregister receiver in onDestroy to prevent memory leaks
        unregisterReceiver(smsListener);
        Log.d("HGP", "SmsListener Unregistered.");
    }
    private void requestDefaultSmsRole(){
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            RoleManager roleManager = getSystemService(RoleManager.class);
            // check if the app is having permission to be as default SMS app
            boolean isRoleAvailable = roleManager.isRoleAvailable(RoleManager.ROLE_SMS);
            if (isRoleAvailable) {
                // check whether your app is already holding the default SMS app role.
                boolean isRoleHeld = roleManager.isRoleHeld(RoleManager.ROLE_SMS);
                if (!isRoleHeld) {
                    intentActivityResultLauncher.launch(roleManager.createRequestRoleIntent(RoleManager.ROLE_SMS));
                } else {
                    Toast.makeText(this,"role is not available for this app",Toast.LENGTH_LONG).show();
                }
            }
        } else {
            Toast.makeText(this,"permission not executed",Toast.LENGTH_LONG).show();

            Intent intent = new  Intent(Telephony.Sms.Intents.ACTION_CHANGE_DEFAULT);
            intent.putExtra(Telephony.Sms.Intents.EXTRA_PACKAGE_NAME, getPackageName());
            startActivityForResult(intent, 1001);
        }
    }
    private void prepareIntentLauncher() {
        intentActivityResultLauncher = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback<>() {
            @Override
            public void onActivityResult(ActivityResult o) {
                if (o.getResultCode() == Activity.RESULT_OK){
                    Toast.makeText(MainActivity.this, "Success requesting ROLE_SMS!", Toast.LENGTH_SHORT).show();
                } else{
                    Toast.makeText(MainActivity.this, "Faied!", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}