package com.example.massageapplication.contact;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.example.massageapplication.R;
import com.example.massageapplication.massage.MessageActivity;
import com.example.massageapplication.massage.SmsAdapter;

import java.util.ArrayList;
import java.util.List;

public class ContactsAdapter extends RecyclerView.Adapter<ContactsAdapter.ContactViewHolder> {
    private final Context context;
    private final List<Contact> contacts;
    private OnItemClickListener listener;

    public interface OnItemClickListener {
        void onItemClick(Contact contact);
    }

    public void setOnItemClickListener(OnItemClickListener listener) {
        this.listener = listener;
    }

    // Constructor
    public ContactsAdapter(Context context, List<Contact> contacts) {
        this.context = context;
        this.contacts = contacts;
    }

    @Override
    public ContactViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.contact_item, parent, false);
        return new ContactViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ContactViewHolder holder, int position) {
        Contact contact = contacts.get(position);
        holder.nameTextView.setText(contact.getName());
        holder.number.setText(contact.getPhone());

            if (contact.getName().length() > 0) {
                String initial = String.valueOf(contact.getName().charAt(0)).toUpperCase();
                holder.firstName.setText(initial);

                // Get a unique color for the initial
                int color = getColorForInitial(initial);

                // Change the background color of the `circle_background` drawable
                holder.nameLay.setBackgroundResource(R.drawable.circle_background); // Ensure the shape is applied
                GradientDrawable background = (GradientDrawable) holder.nameLay.getBackground();
                background.setColor(color); // Set the dynamic color
            }


        holder.itemView.setOnClickListener(v -> {
            if (listener != null) {
                listener.onItemClick(contact);
            }
        });

    }

    private int getColorForInitial(String initial) {
        // Generate color based on the hashcode of the initial
        int hash = Math.abs(initial.hashCode());
        int[] colors = {
                Color.parseColor("#FFCDD4"), // Light red
                Color.parseColor("#F8BBD4"), // Light pink
                Color.parseColor("#E1BEE9"), // Light purple
                Color.parseColor("#D1C4E3"), // Light indigo
                Color.parseColor("#BBDEF5"), // Light blue
                Color.parseColor("#B2EBF5"), // Light cyan
                Color.parseColor("#C8E6C7"), // Light green
                Color.parseColor("#DCEDC9"), // Light lime
                Color.parseColor("#FFF9C3"), // Light yellow
                Color.parseColor("#FFE0B8"), // Light orange
        };
        return colors[hash % colors.length];
    }
    @Override
    public int getItemCount() {
        return contacts.size();
    }

    // ViewHolder for the RecyclerView
    public static class ContactViewHolder extends RecyclerView.ViewHolder {
        TextView nameTextView, firstName,number;

        LinearLayout nameLay;

        public ContactViewHolder(View itemView) {
            super(itemView);
            nameTextView = itemView.findViewById(R.id.contact_name);
            nameLay = itemView.findViewById(R.id.nameLay);
            firstName = itemView.findViewById(R.id.firstName);
            number = itemView.findViewById(R.id.number);
        }
    }

    // Method to get letter drawable based on the first letter of the contact's name

    // Filter contacts by the search query
    public void filterContacts(List<Contact> filteredContacts) {
        this.contacts.clear();
        this.contacts.addAll(filteredContacts);
        notifyDataSetChanged();
    }
}
