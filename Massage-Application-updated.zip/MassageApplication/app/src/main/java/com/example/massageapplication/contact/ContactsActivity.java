package com.example.massageapplication.contact;

import android.annotation.SuppressLint;
import android.content.ContentResolver;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.massageapplication.R;
import com.example.massageapplication.massage.MainActivity;
import com.example.massageapplication.massage.MessageActivity;


import java.util.ArrayList;
import java.util.Date;

public class ContactsActivity extends AppCompatActivity {
    EditText etContactSearch;
    ImageView ivContactBack;
    private ActivityResultLauncher<String> requestPermissionLauncher;
    private ContactsAdapter adapter;
    private ArrayList<Contact> contacts;
    private RecyclerView recyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contacts);

        ivContactBack = findViewById(R.id.ivContactBack);
        etContactSearch = findViewById(R.id.etContactSearch);
        recyclerView = findViewById(R.id.contacts_recycler_view);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        ivContactBack.setOnClickListener(v -> {
            finish();

            overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);

        });


        contacts = new ArrayList<>();

        // Initialize permission request launcher
        requestPermissionLauncher = registerForActivityResult(new ActivityResultContracts.RequestPermission(), isGranted -> {
            if (isGranted) {
                // Permission granted, load contacts
                loadContacts();
            } else {
                Toast.makeText(ContactsActivity.this, "Permission denied", Toast.LENGTH_SHORT).show();
            }
        });

        // Check if permission is granted
        if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            // Request permission
            requestPermissionLauncher.launch(android.Manifest.permission.READ_CONTACTS);
        } else {
            // Permission already granted, load contacts
            loadContacts();
        }

        // Set up search functionality
        etContactSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                filterContacts(s.toString());
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });
    }

    private void loadContacts() {
        ContentResolver cr = getContentResolver();
        @SuppressLint("Recycle") Cursor cursor = cr.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, null, null, null, null);

        if (cursor != null) {
            while (cursor.moveToNext()) {
                String name = cursor.getString(cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME));
                String phone = cursor.getString(cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.NUMBER));

                boolean isDuplicate = false;
                for (Contact contact : contacts) {
                    if (contact.getPhone().equals(phone)) {
                        isDuplicate = true;
                        break;
                    }
                }

                // If it's not a duplicate, add it to the contacts list
                if (!isDuplicate) {
                    contacts.add(new Contact(name, phone));
                }
            }
            cursor.close();
        }

        // Set up adapter
        adapter = new ContactsAdapter(this, new ArrayList<>(contacts));
        recyclerView.setAdapter(adapter);
        adapter.setOnItemClickListener(new ContactsAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(Contact contact) {
                Intent intent = new Intent(ContactsActivity.this, MessageActivity.class);
                intent.putExtra("address", contact.getName());
                intent.putExtra("date", new Date().toString()); // Pass current date or relevant data
                startActivity(intent);
                finish();
            }
        });

    }

    private void filterContacts(String query) {
        ArrayList<Contact> filteredContacts = new ArrayList<>();
        for (Contact contact : contacts) {
            if (contact.getName().toLowerCase().contains(query.toLowerCase())) {
                filteredContacts.add(contact);
            }
        }

        adapter.filterContacts(filteredContacts);
    }
}
