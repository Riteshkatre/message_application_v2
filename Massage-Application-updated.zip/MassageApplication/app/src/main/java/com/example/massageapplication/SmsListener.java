package com.example.massageapplication;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.telephony.SmsMessage;
import android.util.Log;

import androidx.core.app.NotificationCompat;

import com.example.massageapplication.massage.MainActivity;

public class SmsListener extends BroadcastReceiver {

    private static final String CHANNEL_ID = "SMS_CHANNEL";

    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent.getAction().equals("android.provider.Telephony.SMS_RECEIVED")) {
            Bundle bundle = intent.getExtras();
            if (bundle != null) {
                try {
                    Object[] pdus = (Object[]) bundle.get("pdus");
                    SmsMessage[] messages = new SmsMessage[pdus.length];
                    StringBuilder messageBody = new StringBuilder();
                    String sender = "";

                    for (int i = 0; i < messages.length; i++) {
                        messages[i] = SmsMessage.createFromPdu((byte[]) pdus[i]);
                        if (i == 0) {
                            sender = messages[i].getOriginatingAddress(); // Get sender's number
                        }
                        messageBody.append(messages[i].getMessageBody()); // Concatenate message parts
                    }

                    Log.d("SmsListener", "Sender: " + sender + ", Message: " + messageBody);

                    // Show notification
                    showNotification(context, sender, messageBody.toString());
                } catch (Exception e) {
                    Log.e("SmsListener", "Exception: " + e.getMessage());
                }
            }
        }
    }

    private void showNotification(Context context, String sender, String messageBody) {
        Intent serviceIntent = new Intent(context, SmsService.class);
        serviceIntent.putExtra("sender", sender);
        serviceIntent.putExtra("message", messageBody);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.startForegroundService(serviceIntent);
        } else {
            context.startService(serviceIntent);
        }
    }

    private void showNotificationV2(Context context, String sender, String messageBody) {
        // Create NotificationManager
        NotificationManager notificationManager =
                (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);

        // Create a notification channel (required for Android 8.0 and above)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    "SMS Notifications",
                    NotificationManager.IMPORTANCE_HIGH
            );
            channel.setDescription("Channel for SMS notifications");
            notificationManager.createNotificationChannel(channel);
        }

        // Create an intent for launching the app when the notification is clicked
        Intent intent = new Intent(context, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        PendingIntent pendingIntent = PendingIntent.getActivity(
                context, 0, intent, PendingIntent.FLAG_IMMUTABLE);

        // Build the notification
        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.sym_action_email) // Replace with your app icon
                .setContentTitle("New SMS from " + sender)
                .setContentText(messageBody)
                .setStyle(new NotificationCompat.BigTextStyle().bigText(messageBody))
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true)
                .setContentIntent(pendingIntent);

        // Display the notification
        notificationManager.notify(1, builder.build());
    }
}
